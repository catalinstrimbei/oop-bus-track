/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package app.exceptii;

import app.exceptii.AppException;

/**
 *
 * @author catalin
 */
public class ExceptieValidare extends AppException{

    public ExceptieValidare(String message) {
        super(message);
    }
    
}
